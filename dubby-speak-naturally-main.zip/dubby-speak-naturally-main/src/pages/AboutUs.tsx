import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";

const AboutUs = () => {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main className="pt-24">
        {/* Hero Section */}
        <section className="py-24 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-5xl lg:text-6xl font-bold mb-8 text-black">
              About{" "}
              <span className="bg-gradient-primary bg-clip-text text-transparent">
                DUBBY
              </span>
            </h1>
            <p className="text-xl text-black/70 max-w-2xl mx-auto">
              We're building the future of human connection through AI-powered voice translation that preserves personality and cultural context.
            </p>
          </div>
        </section>

        {/* Why we built it */}
        <section className="py-24 bg-lavender/30">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-black mb-6">Why we built it</h2>
            </div>

            <div className="bg-white rounded-3xl p-12 shadow-soft">
              <div className="space-y-6 text-lg text-black/80 leading-relaxed">
                <p>
                  We created Dubby because literal translation just doesn't cut it anymore.
                </p>
                <p>
                  While traveling, we constantly struggled with apps that didn't capture local slang, tone, or context — and left us misunderstood.
                </p>
                <p>
                  Dubby was born out of frustration — and built with one goal:
                </p>
                <blockquote className="text-2xl font-medium text-purple border-l-4 border-purple pl-6 my-8">
                  To help people communicate as if they truly belong — wherever they are.
                </blockquote>
              </div>
            </div>
          </div>
        </section>

        {/* What makes us different */}
        <section className="py-24">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-black mb-6">What makes us different</h2>
            </div>

            <div className="grid md:grid-cols-2 gap-12">
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-bold text-black mb-3">We go beyond translation</h3>
                  <p className="text-black/70">We preserve intent and tone.</p>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-black mb-3">We understand slang</h3>
                  <p className="text-black/70">Dialects and regional nuance.</p>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-black mb-3">We help you speak with cultural awareness</h3>
                  <p className="text-black/70">Real-time cultural insights and etiquette tips.</p>
                </div>
              </div>
              <div className="bg-gradient-primary rounded-3xl p-8 text-white">
                <h3 className="text-2xl font-bold mb-4">Personal voice-first interpreter</h3>
                <p className="mb-4">
                  Dubby is your personal voice-first interpreter, not a word-for-word translator.
                </p>
                <p className="mb-4">
                  Built with AI, refined by real-world travel problems.
                </p>
                <p className="font-medium">
                  Built by travelers, for travelers.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Values */}
        <section className="py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-black mb-6">Our Values</h2>
              <p className="text-xl text-black/70">
                The principles that guide everything we build
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white rounded-3xl p-8 shadow-soft border border-purple/10 text-center">
                <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-6">
                  <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold text-black mb-4">Human-First</h3>
                <p className="text-black/70">
                  Technology should enhance human connection, not replace it. We preserve what makes you uniquely you.
                </p>
              </div>

              <div className="bg-white rounded-3xl p-8 shadow-soft border border-purple/10 text-center">
                <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-6">
                  <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold text-black mb-4">Cultural Respect</h3>
                <p className="text-black/70">
                  Every culture has its nuances. We help you communicate respectfully across all cultural contexts.
                </p>
              </div>

              <div className="bg-white rounded-3xl p-8 shadow-soft border border-purple/10 text-center">
                <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-6">
                  <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold text-black mb-4">Innovation</h3>
                <p className="text-black/70">
                  We push the boundaries of what's possible with AI to create experiences that feel magical.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Roadmap */}
        <section className="py-24 bg-lavender/30">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-black mb-6">What's Next</h2>
              <p className="text-xl text-black/70">
                Our journey to revolutionize human communication
              </p>
            </div>

            <div className="space-y-12">
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white font-bold text-sm">1</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-black mb-2">Q3 2025: Early Access Launch</h3>
                  <p className="text-black/70">
                    Limited beta release for waitlist members. Core voice translation with personality preservation for 10+ languages.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white font-bold text-sm">2</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-black mb-2">Q4 2025: Public Launch</h3>
                  <p className="text-black/70">
                    Full iOS and Android apps with 50+ languages, travel modes, and cultural sensitivity features.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-purple/30 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-purple font-bold text-sm">3</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-black mb-2">2026: Advanced Features</h3>
                  <p className="text-black/70">
                    Real-time conversation mode, professional translation, and integration with popular travel and communication apps.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-24">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-4xl font-bold text-black mb-6">
              Ready to join the journey?
            </h2>
            <p className="text-xl text-black/70 mb-8 max-w-2xl mx-auto">
              Be part of the DUBBY story from the beginning. Join our waitlist and help shape the future of human communication.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                variant="premium"
                size="lg"
                onClick={() => window.location.href = '/waitlist'}
                className="px-8 bg-gradient-primary hover:opacity-90"
              >
                Join Waitlist
              </Button>
              <Button
                variant="premium-outline"
                size="lg"
                onClick={() => window.location.href = '/'}
                className="px-8 border-2 border-black hover:bg-black hover:text-white"
              >
                Back to Home
              </Button>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default AboutUs;