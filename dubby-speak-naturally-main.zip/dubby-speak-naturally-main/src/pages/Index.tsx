import { AnnouncementBar } from "@/components/AnnouncementBar";
import { Header } from "@/components/Header";
import { HeroSection } from "@/components/HeroSection";
import { EnhancedFeaturesSection } from "@/components/EnhancedFeaturesSection";
import { UseCasesSection } from "@/components/UseCasesSection";
import { ComparisonSection } from "@/components/ComparisonSection";
import { DemoSection } from "@/components/DemoSection";
import { FounderSection } from "@/components/FounderSection";
import { Footer } from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen">
      <AnnouncementBar />
      <Header />
      <HeroSection />
      <ComparisonSection />
      <EnhancedFeaturesSection />
      <UseCasesSection />
      <DemoSection />
      <FounderSection />
      <Footer />
    </div>
  );
};

export default Index;