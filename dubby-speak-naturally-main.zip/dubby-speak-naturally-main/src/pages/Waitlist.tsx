import { useState } from "react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

const Waitlist = () => {
  const [email, setEmail] = useState("");
  const [suggestions, setSuggestions] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSignedUp, setIsSignedUp] = useState(false);
  const { toast } = useToast();

  const handleWaitlistSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;

    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('waitlist')
        .insert([
          { 
            email: email.trim(),
            suggestions: suggestions.trim() || null
          }
        ]);

      if (error) {
        if (error.code === '23505') {
          toast({
            title: "Already registered!",
            description: "This email is already on our waitlist.",
            variant: "destructive",
          });
        } else {
          throw error;
        }
      } else {
        setIsSignedUp(true);
        toast({
          title: "Welcome to the waitlist!",
          description: "You're all set for early access to DUBBY.",
        });
      }
    } catch (error) {
      console.error('Error adding to waitlist:', error);
      toast({
        title: "Something went wrong",
        description: "Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main className="pt-24">
        {/* Hero Section */}
        <section className="py-24 bg-purple text-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-5xl lg:text-6xl font-bold mb-8">
              Join the{" "}
              <span className="bg-gradient-to-r from-purple-300 to-pink-300 bg-clip-text text-transparent">
                DUBBY Revolution
              </span>
            </h1>
            <p className="text-xl text-white/80 max-w-2xl mx-auto mb-8">
              Be among the first to experience voice translation that understands your personality, tone, and cultural context.
            </p>
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 max-w-2xl mx-auto">
              <p className="text-lg font-medium">
                Early Access launches Q3 2025
              </p>
            </div>
          </div>
        </section>

        {/* Waitlist Form - Priority Section */}
        <section className="py-24">
          <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
            {!isSignedUp ? (
              <div className="bg-white rounded-3xl p-8 shadow-elegant border border-purple/10">
                <div className="text-center mb-8">
                  <h2 className="text-3xl font-bold text-black mb-4">
                    Reserve Your Spot
                  </h2>
                  <p className="text-black/70">
                    Get exclusive early access and help shape the future of DUBBY.
                  </p>
                </div>

                <form onSubmit={handleWaitlistSignup} className="space-y-6">
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-black mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      id="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="w-full px-4 py-3 border border-purple/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple focus:border-transparent"
                      placeholder="your.email@example.com"
                    />
                  </div>

                  <div>
                    <label htmlFor="suggestions" className="block text-sm font-medium text-black mb-2">
                      How would you use DUBBY?
                    </label>
                    <textarea
                      id="suggestions"
                      value={suggestions}
                      onChange={(e) => setSuggestions(e.target.value)}
                      rows={5}
                      className="w-full px-4 py-3 border border-purple/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple focus:border-transparent resize-none"
                      placeholder="Tell us about your use cases: travel, business, learning languages, connecting with locals..."
                    />
                  </div>

                  <Button
                    type="submit"
                    variant="premium"
                    size="lg"
                    disabled={isLoading}
                    className="w-full py-4 text-lg bg-gradient-primary hover:opacity-90"
                  >
                    {isLoading ? "Joining..." : "Join the Waitlist"}
                  </Button>
                </form>

                <div className="mt-8 space-y-4">
                  <div className="bg-lavender/50 rounded-2xl p-4">
                    <h3 className="font-semibold text-black mb-2">What you'll get:</h3>
                    <ul className="space-y-1 text-sm text-black/70">
                      <li>• First access to DUBBY when it launches</li>
                      <li>• Exclusive updates on development progress</li>
                      <li>• Early beta testing opportunities</li>
                      <li>• Special launch pricing</li>
                    </ul>
                  </div>
                  
                  <p className="text-xs text-black/50 text-center">
                    We respect your privacy. No spam, unsubscribe anytime.
                  </p>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-3xl p-8 shadow-elegant border border-purple/10 text-center">
                <div className="w-20 h-20 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-6">
                  <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h2 className="text-3xl font-bold text-black mb-4">You're in!</h2>
                <p className="text-lg text-black/70 mb-8">
                  Welcome to the DUBBY family! We'll keep you updated on our progress and you'll be the first to know when early access opens.
                </p>
                <div className="bg-lavender/50 rounded-2xl p-6">
                  <h3 className="font-semibold text-black mb-2">What happens next?</h3>
                  <ul className="space-y-2 text-sm text-black/70">
                    <li>• You'll receive a confirmation email shortly</li>
                    <li>• We'll send development updates monthly</li>
                    <li>• Early access invitation in Q3 2025</li>
                  </ul>
                </div>
                
                <div className="mt-8">
                  <Button
                    variant="premium-outline"
                    size="lg"
                    onClick={() => window.location.href = '/'}
                    className="border-2 border-black hover:bg-black hover:text-white"
                  >
                    Back to Home
                  </Button>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* Launch Plan / What's Coming Next */}
        <section className="py-16 bg-lavender/30">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-black mb-4">What's Coming Next</h2>
              <p className="text-lg text-black/60">
                Our roadmap to revolutionizing voice translation
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8 mb-12">
              <div className="bg-white rounded-2xl p-8 shadow-soft">
                <h3 className="text-xl font-bold text-black mb-4">Q3 2025 - Early Access</h3>
                <ul className="space-y-3 text-black/70">
                  <li>• Beta testing with waitlist members</li>
                  <li>• Core voice translation features</li>
                  <li>• iOS app launch</li>
                  <li>• 20+ languages supported</li>
                </ul>
              </div>
              <div className="bg-white rounded-2xl p-8 shadow-soft">
                <h3 className="text-xl font-bold text-black mb-4">Q4 2025 - Full Launch</h3>
                <ul className="space-y-3 text-black/70">
                  <li>• Android app release</li>
                  <li>• Advanced cultural awareness AI</li>
                  <li>• Travel mode features</li>
                  <li>• 50+ languages and dialects</li>
                </ul>
              </div>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white rounded-2xl p-6 shadow-soft text-center">
                <div className="text-3xl font-bold text-purple mb-2">50+</div>
                <div className="text-black/70">Languages Supported</div>
              </div>
              <div className="bg-white rounded-2xl p-6 shadow-soft text-center">
                <div className="text-3xl font-bold text-purple mb-2">95%</div>
                <div className="text-black/70">Context Accuracy</div>
              </div>
              <div className="bg-white rounded-2xl p-6 shadow-soft text-center">
                <div className="text-3xl font-bold text-purple mb-2">&lt;200ms</div>
                <div className="text-black/70">Response Time</div>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Waitlist;