import { useState } from "react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export const FinalSignupSection = () => {
  const [email, setEmail] = useState("");
  const [suggestions, setSuggestions] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSignedUp, setIsSignedUp] = useState(false);
  const { toast } = useToast();

  const handleWaitlistSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;

    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('waitlist')
        .insert([
          { 
            email: email.trim(),
            suggestions: suggestions.trim() || null
          }
        ]);

      if (error) {
        if (error.code === '23505') { // Unique constraint violation
          toast({
            title: "Already registered!",
            description: "This email is already on our waitlist.",
            variant: "destructive",
          });
        } else {
          throw error;
        }
      } else {
        setIsSignedUp(true);
        toast({
          title: "Welcome to the waitlist! 🎉",
          description: "You're all set for early access to DUBBY.",
        });
      }
    } catch (error) {
      console.error('Error adding to waitlist:', error);
      toast({
        title: "Something went wrong",
        description: "Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section id="signup-section" className="py-24 bg-gradient-hero">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6">
            Ready to speak like a local?
          </h2>
          <p className="text-xl text-white/80 max-w-2xl mx-auto">
            Join the DUBBY waitlist and be among the first to experience voice translation that actually gets you.
          </p>
        </div>

        {!isSignedUp ? (
          <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-8 border border-white/20">
            <form onSubmit={handleWaitlistSignup} className="space-y-6">
              <div>
                <label htmlFor="final-email" className="block text-sm font-medium text-white mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  id="final-email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full px-4 py-3 bg-white/20 border border-white/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-white focus:border-transparent text-white placeholder-white/60"
                  placeholder="your.email@example.com"
                />
              </div>

              <div>
                <label htmlFor="final-suggestions" className="block text-sm font-medium text-white mb-2">
                  How would you use DUBBY? (Optional)
                </label>
                <textarea
                  id="final-suggestions"
                  value={suggestions}
                  onChange={(e) => setSuggestions(e.target.value)}
                  rows={4}
                  className="w-full px-4 py-3 bg-white/20 border border-white/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-white focus:border-transparent text-white placeholder-white/60 resize-none"
                  placeholder="Travel, business meetings, learning languages..."
                />
              </div>

              <Button
                type="submit"
                variant="default"
                size="lg"
                disabled={isLoading}
                className="w-full py-4 text-lg bg-white text-black hover:bg-white/90 font-semibold"
              >
                {isLoading ? "Joining..." : "Reserve My Spot"}
              </Button>
            </form>

            <div className="mt-8 text-center space-y-4">
              <p className="text-sm text-white/70">
                🚀 Early access launches Q3 2025
              </p>
              <div className="flex justify-center space-x-8 text-sm text-white/60">
                <span>✓ No spam, ever</span>
                <span>✓ Exclusive updates</span>
                <span>✓ First access</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-8 border border-white/20 text-center">
            <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-6">
              <svg className="w-8 h-8 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">You're all set! 🎉</h3>
            <p className="text-lg text-white/80 mb-6">
              Welcome to the DUBBY family. We'll keep you updated on our progress and notify you the moment early access opens.
            </p>
            <div className="bg-white/20 rounded-2xl p-4">
              <p className="text-sm text-white font-medium">
                📱 DUBBY launches Q3 2025 - You'll be first to know!
              </p>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};