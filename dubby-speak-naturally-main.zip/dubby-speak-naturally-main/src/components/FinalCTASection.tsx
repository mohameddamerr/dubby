import { useState } from "react";
import { Button } from "@/components/ui/button";

export const FinalCTASection = () => {
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setIsSubmitted(true);
      // Here you would typically integrate with your email service
      console.log("Email submitted:", email);
    }
  };

  return (
    <section id="signup-section" className="py-20 bg-gradient-hero relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute top-1/4 left-10 w-32 h-32 bg-sky-blue/20 rounded-full blur-xl animate-pulse-glow"></div>
      <div className="absolute bottom-1/4 right-10 w-24 h-24 bg-primary/20 rounded-full blur-xl animate-pulse-glow delay-1000"></div>
      
      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Main Headline */}
        <h2 className="text-4xl lg:text-6xl font-bold text-white mb-6 animate-fade-in">
          Talk to anyone, anywhere —{" "}
          <span className="bg-gradient-to-r from-purple to-white bg-clip-text text-transparent">
            and truly connect.
          </span>
        </h2>

        {/* Subheadline */}
        <p className="text-xl lg:text-2xl text-white/80 mb-12 max-w-3xl mx-auto leading-relaxed animate-slide-up">
          Get early access to Dubby and be among the first to experience 
          AI translation that preserves your voice and personality.
        </p>

        {/* Waitlist Form */}
        {!isSubmitted ? (
          <form onSubmit={handleSubmit} className="max-w-lg mx-auto mb-12 animate-scale-in">
            <div className="flex flex-col sm:flex-row gap-4">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email address"
                className="flex-1 px-6 py-4 rounded-xl text-foreground bg-white/95 backdrop-blur-sm border border-white/20 focus:outline-none focus:ring-2 focus:ring-purple focus:border-transparent transition-all duration-300"
                required
              />
              <Button 
                type="submit" 
                variant="premium" 
                size="lg" 
                className="px-8 py-4 whitespace-nowrap"
              >
                🎧 Get Early Access to Dubby
              </Button>
            </div>
            <p className="text-white/60 text-sm mt-4">
              ✨ No spam, just updates on beta launch and exclusive early access
            </p>
          </form>
        ) : (
          <div className="max-w-lg mx-auto mb-12 animate-scale-in">
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
              <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-white mb-3">You're on the list!</h3>
              <p className="text-white/80">
                We'll notify you as soon as Dubby beta is ready. Get ready to break down language barriers!
              </p>
            </div>
          </div>
        )}

        {/* Secondary CTA */}
        <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-12">
          <Button variant="premium-outline" size="lg" className="px-8 py-4">
            Watch Demo Video
          </Button>
          <Button variant="premium-outline" size="lg" className="px-8 py-4">
            Download Press Kit
          </Button>
        </div>

        {/* Launch Timeline */}
        <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 max-w-2xl mx-auto mb-12">
          <h3 className="text-xl font-bold text-white mb-6">Launch Timeline</h3>
          <div className="space-y-4 text-left">
            <div className="flex items-center space-x-4">
              <div className="w-3 h-3 bg-green-400 rounded-full"></div>
              <div>
                <div className="text-white font-medium">Q1 2025 - Alpha Testing</div>
                <div className="text-white/60 text-sm">Closed beta with select users</div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="w-3 h-3 bg-purple rounded-full animate-pulse"></div>
              <div>
                <div className="text-white font-medium">Q3 2025 - Public Beta</div>
                <div className="text-white/60 text-sm">Open beta launch with core features</div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="w-3 h-3 bg-white/40 rounded-full"></div>
              <div>
                <div className="text-white font-medium">Q4 2025 - Full Launch</div>
                <div className="text-white/60 text-sm">Complete platform with enterprise features</div>
              </div>
            </div>
          </div>
        </div>

        {/* Social Proof Preview */}
        <div className="grid md:grid-cols-3 gap-6 text-center">
          <div>
            <div className="text-3xl font-bold text-white mb-2">10,000+</div>
            <div className="text-white/60">Waitlist Signups</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-white mb-2">50+</div>
            <div className="text-white/60">Languages Supported</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-white mb-2">95%</div>
            <div className="text-white/60">Context Accuracy</div>
          </div>
        </div>

        {/* Fine Print */}
        <p className="text-white/40 text-xs mt-12 max-w-2xl mx-auto">
          By joining our waitlist, you agree to receive email updates about Dubby. 
          You can unsubscribe at any time. We respect your privacy and will never share your email.
        </p>
      </div>
    </section>
  );
};