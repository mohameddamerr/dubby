const features = [
  {
    title: "Real-Time Voice Translation",
    description: "Speak naturally and get instant translations that capture your exact meaning and intention.",
    visual: "mic"
  },
  {
    title: "Dialect & Tone Recognition", 
    description: "AI that understands slang, regional expressions, and the emotional context behind your words.",
    visual: "tone"
  },
  {
    title: "Context-Aware AI",
    description: "Same phrase, different meanings - DUBBY knows when you're being sarcastic, excited, or serious.",
    visual: "context"
  },
  {
    title: "Travel Modes",
    description: "Smart context switching for taxi rides, hotel check-ins, airport navigation, and local exploration.",
    visual: "travel"
  },
  {
    title: "Cultural Sensitivity",
    description: "Real-time alerts when your phrase might be misunderstood or culturally inappropriate.",
    visual: "culture"
  }
];

const FeatureVisual = ({ type }: { type: string }) => {
  const baseClasses = "w-full h-32 rounded-xl flex items-center justify-center";
  
  switch (type) {
    case "mic":
      return (
        <div className={`${baseClasses} bg-gradient-primary`}>
          <svg width="48" height="48" viewBox="0 0 48 48" className="text-white">
            <path 
              d="M16 18c0-3 2.5-6 6-6s6 3 6 6v12c0 3-2.5 6-6 6s-6-3-6-3v-12z" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="3" 
              strokeLinecap="round"
              className="animate-draw"
              style={{ strokeDasharray: 150, strokeDashoffset: 150 }}
            />
            <path d="M12 30c0 5.5 4.5 10 10 10s10-4.5 10-10M22 40v6M18 46h8" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
          </svg>
        </div>
      );
    case "tone":
      return (
        <div className={`${baseClasses} bg-lavender`}>
          <svg width="48" height="48" viewBox="0 0 48 48" className="text-purple">
            <path d="M24 8c8 0 16 6 16 14s-8 14-16 14-16-6-16-14 8-14 16-14z" fill="none" stroke="currentColor" strokeWidth="2"/>
            <path d="M18 22c2 4 6 4 8 0M16 18h4M28 18h4" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
          </svg>
        </div>
      );
    case "context":
      return (
        <div className={`${baseClasses} bg-gradient-card border border-purple/20`}>
          <svg width="48" height="48" viewBox="0 0 48 48" className="text-purple">
            <path d="M12 12h24v24H12z" fill="none" stroke="currentColor" strokeWidth="2"/>
            <path d="M16 20h16M16 24h12M16 28h8" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
          </svg>
        </div>
      );
    case "travel":
      return (
        <div className={`${baseClasses} bg-gradient-primary`}>
          <svg width="48" height="48" viewBox="0 0 48 48" className="text-white">
            <path d="M24 6v36M6 24h36" stroke="currentColor" strokeWidth="2"/>
            <circle cx="24" cy="24" r="18" fill="none" stroke="currentColor" strokeWidth="2"/>
            <circle cx="24" cy="24" r="3" fill="currentColor"/>
          </svg>
        </div>
      );
    case "culture":
      return (
        <div className={`${baseClasses} bg-lavender`}>
          <svg width="48" height="48" viewBox="0 0 48 48" className="text-purple">
            <circle cx="24" cy="24" r="18" fill="none" stroke="currentColor" strokeWidth="2"/>
            <path d="M24 16v8l6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            <circle cx="36" cy="12" r="6" fill="none" stroke="currentColor" strokeWidth="2"/>
            <path d="M36 9v6M33 12h6" stroke="currentColor" strokeWidth="2"/>
          </svg>
        </div>
      );
    default:
      return <div className={`${baseClasses} bg-lavender`}></div>;
  }
};

export const FeaturesSection = () => {
  return (
    <section id="features" className="py-24 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-20">
          <h2 className="text-4xl lg:text-5xl font-bold text-black mb-8">
            Built for humans,{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              powered by AI
            </span>
          </h2>
          <p className="text-xl text-black/70 max-w-3xl mx-auto">
            Every feature designed to make conversations feel natural, culturally appropriate, and genuinely human.
          </p>
        </div>

        {/* Features List - Alternating Layout */}
        <div className="space-y-32">
          {features.map((feature, index) => (
            <div
              key={index}
              className={`flex flex-col ${
                index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'
              } items-center gap-16`}
            >
              {/* Visual */}
              <div className="w-full lg:w-1/2">
                <FeatureVisual type={feature.visual} />
              </div>

              {/* Content */}
              <div className="w-full lg:w-1/2 space-y-6">
                <h3 className="text-3xl lg:text-4xl font-bold text-black leading-tight">
                  {feature.title}
                </h3>
                <p className="text-xl text-black/70 leading-relaxed">
                  {feature.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};