export const ProblemPromiseSection = () => {
  return (
    <section className="py-24 bg-lavender/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Problem Side */}
          <div className="space-y-8">
            <div className="text-center lg:text-left">
              <h2 className="text-4xl lg:text-5xl font-bold text-black mb-8">
                Translation tools miss the point
              </h2>
            </div>
            
            <div className="space-y-6">
              <div className="flex items-start space-x-4 group">
                <div className="flex-shrink-0 w-10 h-10 bg-red-100 rounded-full flex items-center justify-center group-hover:bg-red-200 transition-all duration-300">
                  <svg className="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-semibold text-black mb-2 text-lg">Literal translation kills meaning</h3>
                  <p className="text-black/70">Word-for-word translation destroys context and cultural nuance.</p>
                </div>
              </div>

              <div className="flex items-start space-x-4 group">
                <div className="flex-shrink-0 w-10 h-10 bg-red-100 rounded-full flex items-center justify-center group-hover:bg-red-200 transition-all duration-300">
                  <svg className="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-semibold text-black mb-2 text-lg">Robotic voices break the moment</h3>
                  <p className="text-black/70">Artificial pronunciation ruins natural conversation flow.</p>
                </div>
              </div>

              <div className="flex items-start space-x-4 group">
                <div className="flex-shrink-0 w-10 h-10 bg-red-100 rounded-full flex items-center justify-center group-hover:bg-red-200 transition-all duration-300">
                  <svg className="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-semibold text-black mb-2 text-lg">Most tools don't understand dialects or tone</h3>
                  <p className="text-black/70">Regional expressions and emotional context get completely lost.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Promise Side */}
          <div className="space-y-8">
            <div className="text-center lg:text-left">
              <h2 className="text-4xl lg:text-5xl font-bold text-black mb-8">
                Dubby gets{" "}
                <span className="bg-gradient-primary bg-clip-text text-transparent">
                  you
                </span>
              </h2>
            </div>
            
            <div className="space-y-6">
              <div className="flex items-start space-x-4 group">
                <div className="flex-shrink-0 w-10 h-10 bg-purple/20 rounded-full flex items-center justify-center group-hover:bg-purple/30 transition-all duration-300">
                  <svg className="w-5 h-5 text-purple" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-semibold text-black mb-2 text-lg">Natural, human-like translations</h3>
                  <p className="text-black/70">AI that captures the essence of what you really mean to say.</p>
                </div>
              </div>

              <div className="flex items-start space-x-4 group">
                <div className="flex-shrink-0 w-10 h-10 bg-purple/20 rounded-full flex items-center justify-center group-hover:bg-purple/30 transition-all duration-300">
                  <svg className="w-5 h-5 text-purple" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-semibold text-black mb-2 text-lg">Understands how you speak, not just what you say</h3>
                  <p className="text-black/70">Recognizes tone, emotion, and intent behind your words.</p>
                </div>
              </div>

              <div className="flex items-start space-x-4 group">
                <div className="flex-shrink-0 w-10 h-10 bg-purple/20 rounded-full flex items-center justify-center group-hover:bg-purple/30 transition-all duration-300">
                  <svg className="w-5 h-5 text-purple" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-semibold text-black mb-2 text-lg">Speaks like a local, with your intent</h3>
                  <p className="text-black/70">Delivers authentic regional expressions with your personality intact.</p>
                </div>
              </div>
            </div>

            <div className="pt-8">
              <div className="bg-gradient-card rounded-3xl p-8 shadow-card border border-purple/10">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="w-12 h-12 bg-gradient-primary rounded-full flex items-center justify-center">
                    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                  </div>
                  <h4 className="font-bold text-black text-xl">Like having a local friend everywhere</h4>
                </div>
                <p className="text-black/70">
                  The first mobile translator that preserves your personality and makes every conversation feel natural.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};