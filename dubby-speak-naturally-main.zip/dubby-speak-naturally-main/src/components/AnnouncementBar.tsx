export const AnnouncementBar = () => {
  return (
    <a 
      href="/waitlist"
      className="block w-full py-3 px-4 text-center relative overflow-hidden bg-gradient-announcement bg-[length:400%_400%] animate-announcement cursor-pointer group shadow-sm"
    >
      <div className="relative z-10">
        <p className="text-sm font-semibold text-white group-hover:scale-105 transition-transform">
          Special offer for early users — Join the waitlist
        </p>
      </div>
    </a>
  );
};