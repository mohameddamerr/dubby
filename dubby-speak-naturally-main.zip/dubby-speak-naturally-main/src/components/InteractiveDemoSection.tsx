import { useState } from "react";
import { Button } from "@/components/ui/button";

export const InteractiveDemoSection = () => {
  const [inputLanguage, setInputLanguage] = useState("Arabic");
  const [outputLanguage, setOutputLanguage] = useState("French - Parisian");
  const [isPlaying, setIsPlaying] = useState(false);

  const languages = [
    "Arabic", "English", "Spanish", "French - Parisian", "Chinese - Mandarin", 
    "Japanese", "German", "Italian", "Portuguese", "Russian"
  ];

  const demoExamples = {
    "Arabic": {
      text: "أنا جعان، أين أفضل مطعم في المنطقة؟",
      translation: {
        "French - Parisian": {
          text: "J'ai faim, où est le meilleur restaurant du quartier ?",
          tone: "Friendly & Curious"
        },
        "English": {
          text: "I'm hungry, where's the best restaurant around here?",
          tone: "Casual & Direct"
        },
        "Spanish": {
          text: "Tengo hambre, ¿dónde está el mejor restaurante de la zona?",
          tone: "Warm & Polite"
        }
      }
    },
    "English": {
      text: "I'm feeling a bit overwhelmed by all these options.",
      translation: {
        "French - Parisian": {
          text: "Je me sens un peu dépassé par toutes ces options.",
          tone: "Thoughtful & Honest"
        },
        "Spanish": {
          text: "Me siento un poco abrumado por todas estas opciones.",
          tone: "Vulnerable & Authentic"
        }
      }
    }
  };

  const currentDemo = demoExamples[inputLanguage as keyof typeof demoExamples];
  const currentTranslation = currentDemo?.translation[outputLanguage as keyof typeof currentDemo.translation];

  const handlePlayDemo = () => {
    setIsPlaying(true);
    setTimeout(() => setIsPlaying(false), 2000);
  };

  return (
    <section id="demo-section" className="py-20 bg-secondary/30">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-6xl font-bold text-black mb-8">
            Try DUBBY{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              yourself
            </span>
          </h2>
          <p className="text-xl text-black/70 max-w-3xl mx-auto">
            Experience real-time AI translation that captures tone, context, and cultural nuance.
          </p>
        </div>

        {/* Demo Interface */}
        <div className="bg-card rounded-3xl shadow-elegant border border-border/50 overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-hero p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-red-400 rounded-full"></div>
                <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                <div className="w-3 h-3 bg-green-400 rounded-full"></div>
              </div>
              <span className="text-white/80 text-sm font-medium">Live Translation Demo</span>
            </div>
          </div>

          {/* Language Selection */}
          <div className="p-6 bg-secondary/20 border-b border-border/50">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Input Language
                </label>
                <select 
                  value={inputLanguage}
                  onChange={(e) => setInputLanguage(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
                >
                  {languages.map((lang) => (
                    <option key={lang} value={lang}>{lang}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Output Language
                </label>
                <select 
                  value={outputLanguage}
                  onChange={(e) => setOutputLanguage(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
                >
                  {languages.map((lang) => (
                    <option key={lang} value={lang}>{lang}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Demo Content */}
          <div className="p-6 lg:p-8">
            {currentDemo && currentTranslation ? (
              <div className="space-y-6">
                {/* Original Text */}
                <div className="bg-navy/5 rounded-2xl p-6 border border-border/30">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium text-muted-foreground">
                      Original ({inputLanguage})
                    </span>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                      <span className="text-xs text-muted-foreground">Listening</span>
                    </div>
                  </div>
                  <p className="text-lg font-medium text-foreground leading-relaxed">
                    {currentDemo.text}
                  </p>
                </div>

                {/* Translation Arrow */}
                <div className="flex justify-center">
                  <div className={`w-12 h-12 bg-gradient-primary rounded-full flex items-center justify-center shadow-glow transition-all duration-300 ${isPlaying ? 'animate-pulse-glow scale-110' : ''}`}>
                    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                  </div>
                </div>

                {/* Translated Text */}
                <div className="bg-gradient-card rounded-2xl p-6 border border-primary/20">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium text-muted-foreground">
                      Translation ({outputLanguage})
                    </span>
                    <div className="flex items-center space-x-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={handlePlayDemo}
                        disabled={isPlaying}
                        className="text-xs"
                      >
                        {isPlaying ? (
                          <>
                            <div className="w-3 h-3 border border-primary border-t-transparent rounded-full animate-spin mr-1"></div>
                            Playing...
                          </>
                        ) : (
                          <>
                            <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h1m4 0h1m-6 4h8m-6 4h8M9 6h8" />
                            </svg>
                            Play Audio
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                  <p className="text-lg font-medium text-foreground leading-relaxed mb-3">
                    {currentTranslation.text}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-primary font-medium bg-primary/10 px-3 py-1 rounded-full">
                      Tone: {currentTranslation.tone}
                    </span>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      Translated in 150ms
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row gap-4 justify-center pt-6">
                  <Button variant="premium" size="lg" className="px-8">
                    Try Your Own Voice
                  </Button>
                  <Button variant="outline" size="lg" className="px-8">
                    See More Examples
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-muted-foreground">
                  Select different language combinations to see demo translations.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Features Preview */}
        <div className="mt-12 grid md:grid-cols-3 gap-6">
          <div className="text-center p-6 bg-card rounded-2xl shadow-card">
            <div className="w-12 h-12 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 className="font-semibold text-foreground mb-2">Real-Time Processing</h3>
            <p className="text-sm text-muted-foreground">Instant translation with no noticeable delay</p>
          </div>

          <div className="text-center p-6 bg-card rounded-2xl shadow-card">
            <div className="w-12 h-12 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
              </svg>
            </div>
            <h3 className="font-semibold text-foreground mb-2">Tone Recognition</h3>
            <p className="text-sm text-muted-foreground">Captures emotional context and personality</p>
          </div>

          <div className="text-center p-6 bg-card rounded-2xl shadow-card">
            <div className="w-12 h-12 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064" />
              </svg>
            </div>
            <h3 className="font-semibold text-foreground mb-2">Cultural Intelligence</h3>
            <p className="text-sm text-muted-foreground">Adapts to local customs and expressions</p>
          </div>
        </div>
      </div>
    </section>
  );
};