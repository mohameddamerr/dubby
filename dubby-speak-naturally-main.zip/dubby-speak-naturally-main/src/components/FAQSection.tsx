import { useState } from "react";

export const FAQSection = () => {
  const [openFAQ, setOpenFAQ] = useState<number | null>(0);

  const faqs = [
    {
      question: "Does Dubby need internet?",
      answer: "Yes, for now. Dubby uses cloud-based AI processing to deliver the most accurate translations possible. We're working on offline capabilities that will be available in a future update."
    },
    {
      question: "Is the voice human or robotic?",
      answer: "Human-like AI voices! We use advanced neural voice synthesis that captures natural speech patterns, intonation, and emotional expression. The result sounds remarkably human and preserves your personality."
    },
    {
      question: "Can I use it for meetings?",
      answer: "Absolutely! We're building integration with Zoom, Teams, and other video conferencing platforms. The beta will include basic meeting support, with full enterprise features coming in the stable release."
    },
    {
      question: "How accurate is the translation?",
      answer: "We use AI to understand intent, not just words. Our context-aware system achieves 95% accuracy in meaning preservation, significantly outperforming traditional word-for-word translation tools."
    },
    {
      question: "Will it work with AirPods?",
      answer: "Yes! Fully voice-driven mode with AirPods and other Bluetooth devices is coming soon. You'll be able to have seamless conversations without touching your phone."
    }
  ];

  return (
    <section className="py-20 bg-background">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-5xl font-bold text-foreground mb-6">
            Frequently Asked Questions
          </h2>
          <p className="text-xl text-muted-foreground">
            Everything you need to know about Dubby's AI translation technology.
          </p>
        </div>

        {/* FAQ Items */}
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-card rounded-2xl border border-border/50 shadow-card overflow-hidden transition-all duration-300 hover:shadow-elegant"
            >
              <button
                className="w-full px-6 lg:px-8 py-6 text-left focus:outline-none focus:ring-2 focus:ring-primary/20 rounded-2xl transition-all duration-300"
                onClick={() => setOpenFAQ(openFAQ === index ? null : index)}
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-foreground pr-4">
                    {faq.question}
                  </h3>
                  <div className={`flex-shrink-0 w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center transition-transform duration-300 ${openFAQ === index ? 'rotate-180' : ''}`}>
                    <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </div>
                </div>
              </button>
              
              <div className={`transition-all duration-300 ease-in-out ${openFAQ === index ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'} overflow-hidden`}>
                <div className="px-6 lg:px-8 pb-6">
                  <p className="text-muted-foreground leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Additional Support */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-card rounded-2xl p-8 shadow-card">
            <h3 className="text-2xl font-bold text-foreground mb-4">
              Still have questions?
            </h3>
            <p className="text-muted-foreground mb-6">
              Our team is here to help you understand how Dubby can transform your communication.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-gradient-primary text-white px-6 py-3 rounded-xl font-semibold hover:shadow-glow transition-all duration-300 hover:scale-105">
                Contact Support
              </button>
              <button className="border border-border text-foreground px-6 py-3 rounded-xl font-semibold hover:bg-secondary transition-all duration-300">
                Join Community
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};