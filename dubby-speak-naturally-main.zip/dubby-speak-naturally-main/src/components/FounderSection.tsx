export const FounderSection = () => {
  return (
    <section className="py-24 bg-lavender/30">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl p-12 shadow-soft border border-purple/10">
          {/* Quote block */}
          <blockquote className="text-center">
            <div className="text-6xl text-navy/20 mb-6">"</div>
            <div className="space-y-6 text-xl text-black/80 leading-relaxed italic">
              <p>
                I struggled speaking with locals while traveling — especially when tone and slang mattered.
              </p>
              <p>
                Literal translations failed me every time.
              </p>
              <p>
                That's why I built DUBBY — not just to translate words, but to capture the way we speak, 
                the way we mean it.
              </p>
            </div>
            <div className="text-6xl text-navy/20 mt-6 rotate-180">"</div>
          </blockquote>
        </div>
      </div>
    </section>
  );
};