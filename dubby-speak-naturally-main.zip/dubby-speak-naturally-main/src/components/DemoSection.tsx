import { Button } from "@/components/ui/button";

export const DemoSection = () => {
  return (
    <section id="demo-section" className="py-24 bg-lavender/30">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-4xl lg:text-5xl font-bold text-black mb-6">
            Ready to try{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              DUBBY?
            </span>
          </h2>
          <p className="text-xl text-black/70 mb-8">
            Join our waitlist to unlock the interactive demo and be the first to experience real-time voice translation.
          </p>
          
          <Button
            variant="premium"
            size="lg"
            onClick={() => window.location.href = '/waitlist'}
            className="px-10 py-4 text-lg bg-gradient-primary hover:opacity-90"
          >
            Join Waitlist
          </Button>
        </div>
      </div>
    </section>
  );
};