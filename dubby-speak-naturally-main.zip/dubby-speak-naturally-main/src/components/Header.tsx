import { Button } from "@/components/ui/button";

export const Header = () => {
  const handleJoinWaitlist = () => {
    window.location.href = '/waitlist';
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/40 backdrop-blur-xl border-b border-lavender/30">
      <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
        {/* Hand-drawn Logo */}
        <a href="/" className="flex items-center space-x-3">
          <div className="relative">
            <svg width="32" height="32" viewBox="0 0 32 32" className="text-black">
              <path 
                d="M8 12c0-2 1.5-4 4-4s4 2 4 4v8c0 2-1.5 4-4 4s-4-2-4-4v-8z" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2.5" 
                strokeLinecap="round"
                className="animate-draw"
                style={{ strokeDasharray: 100, strokeDashoffset: 100 }}
              />
              <path 
                d="M20 16c1 0 2-1 3-1s2 1 3 1M20 20c1.5 0 3-1 4.5-1s3 1 4.5 1M20 12c1 0 2-1 3-1s2 1 3 1" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round"
                className="animate-draw"
                style={{ strokeDasharray: 50, strokeDashoffset: 50, animationDelay: '0.5s' }}
              />
            </svg>
          </div>
          <span className="text-xl font-bold text-black tracking-wider">DUBBY</span>
        </a>

        {/* Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <a href="/waitlist" className="text-black hover:text-purple transition-colors font-medium">
            Demo
          </a>
          <a href="#features" className="text-black hover:text-purple transition-colors font-medium">
            Features
          </a>
          <a href="/about-us" className="text-black hover:text-purple transition-colors font-medium">
            About
          </a>
        </nav>

        {/* CTA Button */}
        <Button 
          variant="premium" 
          size="sm" 
          onClick={handleJoinWaitlist}
          className="px-6 bg-gradient-primary hover:opacity-90"
        >
          Join Waitlist
        </Button>
      </div>
    </header>
  );
};