export const ComparisonSection = () => {
  const features = [
    {
      feature: "Voice-first",
      dubby: "✅",
      google: "❌",
      ai: "⚠️ Limited"
    },
    {
      feature: "Context understanding",
      dubby: "✅ Understands tone",
      google: "❌ Literal only",
      ai: "⚠️ Basic intent"
    },
    {
      feature: "Dialect + slang detection",
      dubby: "✅ Native-like",
      google: "❌ Formal only",
      ai: "⚠️ Inconsistent"
    },
    {
      feature: "Cultural awareness",
      dubby: "✅ Real-time alerts",
      google: "❌ No awareness",
      ai: "⚠️ None"
    },
    {
      feature: "Mobile optimization",
      dubby: "✅ Fast + AirPods",
      google: "⚠️ Browser focused",
      ai: "⚠️ Not optimized"
    }
  ];

  return (
    <section className="py-24 bg-lavender/20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-black mb-6">
            Why DUBBY is{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              different
            </span>
          </h2>
          <p className="text-xl text-black/70 max-w-3xl mx-auto">
            See how DUBBY compares to traditional translation apps
          </p>
        </div>

        <div className="bg-white rounded-3xl shadow-elegant overflow-hidden border border-purple/10">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gradient-primary">
                <tr>
                  <th className="px-6 py-6 text-left text-lg font-bold text-white">Feature</th>
                  <th className="px-6 py-6 text-center text-lg font-bold text-white">DUBBY ✅</th>
                  <th className="px-6 py-6 text-center text-lg font-bold text-white/80">Google Translate ❌</th>
                  <th className="px-6 py-6 text-center text-lg font-bold text-white/80">AI Translators ⚠️</th>
                </tr>
              </thead>
              <tbody>
                {features.map((item, index) => (
                <tr key={index} className={`border-b border-lavender/50 ${index % 2 === 0 ? 'bg-white' : 'bg-lavender/30'}`}>
                    <td className="px-6 py-6 font-semibold text-black">{item.feature}</td>
                    <td className="px-6 py-6 text-center text-navy font-medium">
                      {item.dubby}
                    </td>
                    <td className="px-6 py-6 text-center text-black/60">{item.google}</td>
                    <td className="px-6 py-6 text-center text-black/60">{item.ai}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
};