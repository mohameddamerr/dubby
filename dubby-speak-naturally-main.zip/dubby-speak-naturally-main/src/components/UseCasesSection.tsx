import { Button } from "@/components/ui/button";

export const UseCasesSection = () => {
  const useCases = [
    {
      input: "Ana ga3an mot",
      output: "I'm starving, bro."
    },
    {
      input: "Estoy flipando",
      output: "I'm freaking out"
    },
    {
      input: "Ça craint",
      output: "That sucks"
    },
    {
      input: "Gimme the deets",
      output: "Tell me the details"
    },
    {
      input: "C'est chelou",
      output: "That's sketchy"
    },
    {
      input: "Yalla ne'mshi",
      output: "Let's bounce"
    },
    {
      input: "J'ai la dalle",
      output: "I'm starving"
    }
  ];

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-20">
          <h2 className="text-4xl lg:text-5xl font-bold text-black mb-8">
            Real conversations,{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              real situations
            </span>
          </h2>
          <p className="text-xl text-black/70 max-w-3xl mx-auto">
            See how DUBBY captures slang, tone, and cultural context in conversations that matter.
          </p>
        </div>

        {/* Use Cases Table */}
        <div className="overflow-x-auto mb-16">
          <table className="w-full border-collapse bg-white rounded-2xl overflow-hidden shadow-soft">
            <thead>
              <tr className="bg-gradient-primary text-white">
                <th className="px-6 py-4 text-left font-semibold">Input</th>
                <th className="px-6 py-4 text-left font-semibold">Output</th>
              </tr>
            </thead>
            <tbody>
              {useCases.map((useCase, index) => (
                <tr key={index} className="border-b border-lavender/50 hover:bg-lavender/20 transition-colors">
                  <td className="px-6 py-6">
                    <div className="font-medium text-black text-lg">
                      "{useCase.input}"
                    </div>
                  </td>
                  <td className="px-6 py-6">
                    <div className="font-medium text-black text-lg">
                      "{useCase.output}"
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Bottom CTA */}
        <div className="text-center">
          <div className="bg-gradient-card rounded-3xl p-8 shadow-soft max-w-2xl mx-auto border border-purple/10">
            <h3 className="text-2xl font-bold text-black mb-4">
              Ready to connect across cultures?
            </h3>
            <p className="text-black/70 mb-6">
              Join thousands who are breaking down language barriers with natural, context-aware translation.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                variant="premium" 
                size="lg" 
                className="px-8 bg-gradient-primary hover:opacity-90"
                onClick={() => window.location.href = '/waitlist'}
              >
                Try Demo
              </Button>
              <Button 
                variant="premium-outline" 
                size="lg" 
                className="px-8 border-2 border-black hover:bg-black hover:text-white"
                onClick={() => window.location.href = '/waitlist'}
              >
                Join Waitlist
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};