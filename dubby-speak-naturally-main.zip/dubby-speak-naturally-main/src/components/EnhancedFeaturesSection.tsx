const features = [
  {
    title: "Voice-first AI Translation",
    subtitle: "Just speak — no typing",
    description: "Talk naturally and get instant translations that preserve your personality and tone.",
    visual: "voice"
  },
  {
    title: "Context-aware Understanding", 
    subtitle: "Knows your tone, intent, and emotion",
    description: "AI that understands what you mean, not just the words you say.",
    visual: "context"
  },
  {
    title: "Dialect & Region Matching",
    subtitle: "Speaks like a local wherever you go",
    description: "Adapts to regional expressions, accents, and cultural nuances for authentic communication.",
    visual: "dialect"
  },
  {
    title: "Travel Modes",
    subtitle: "Tailored phrases for airport, hotel, and taxi",
    description: "Smart context switching for different travel scenarios with location-aware suggestions.",
    visual: "travel"
  },
  {
    title: "Cultural Awareness AI",
    subtitle: "Warns if your phrase might offend",
    description: "Real-time cultural insights and etiquette tips to navigate conversations safely.",
    visual: "culture"
  },
  {
    title: "Built for Mobile",
    subtitle: "Fast, intuitive, and works with AirPods too",
    description: "Optimized for on-the-go use with seamless integration into your mobile workflow.",
    visual: "mobile"
  },
  {
    title: "Conversation History",
    subtitle: "Save your past conversations",
    description: "Let users access their translation history easily, organized by time and language.",
    visual: "chat"
  }
];

const FeatureVisual = ({ type }: { type: string }) => {
  const baseClasses = "w-full h-48 rounded-xl flex items-center justify-center";
  
  switch (type) {
    case "voice":
      return (
        <div className={`${baseClasses} bg-gradient-primary`}>
          <svg width="64" height="64" viewBox="0 0 64 64" className="text-white">
            <path 
              d="M20 24c0-4 3-8 8-8s8 4 8 8v16c0 4-3 8-8 8s-8-4-8-8v-16z" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="3" 
              strokeLinecap="round"
            />
            <path d="M16 40c0 6.6 5.4 12 12 12s12-5.4 12-12M28 52v8M24 60h8" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"/>
          </svg>
        </div>
      );
    case "context":
      return (
        <div className={`${baseClasses} bg-lavender border border-purple/20`}>
          <svg width="64" height="64" viewBox="0 0 64 64" className="text-purple">
            <path d="M16 16h32v32H16z" fill="none" stroke="currentColor" strokeWidth="2.5"/>
            <path d="M22 26h20M22 32h16M22 38h12" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"/>
          </svg>
        </div>
      );
    case "dialect":
      return (
        <div className={`${baseClasses} bg-gradient-primary`}>
          <svg width="64" height="64" viewBox="0 0 64 64" className="text-white">
            <circle cx="32" cy="32" r="24" fill="none" stroke="currentColor" strokeWidth="2.5"/>
            <path d="M32 12v40M12 32h40" stroke="currentColor" strokeWidth="2"/>
            <circle cx="32" cy="32" r="4" fill="currentColor"/>
          </svg>
        </div>
      );
    case "travel":
      return (
        <div className={`${baseClasses} bg-lavender border border-purple/20`}>
          <svg width="64" height="64" viewBox="0 0 64 64" className="text-purple">
            <path d="M16 20h32l-4 8H20z" fill="none" stroke="currentColor" strokeWidth="2.5"/>
            <circle cx="22" cy="36" r="4" fill="none" stroke="currentColor" strokeWidth="2.5"/>
            <circle cx="42" cy="36" r="4" fill="none" stroke="currentColor" strokeWidth="2.5"/>
          </svg>
        </div>
      );
    case "culture":
      return (
        <div className={`${baseClasses} bg-gradient-primary`}>
          <svg width="64" height="64" viewBox="0 0 64 64" className="text-white">
            <circle cx="32" cy="32" r="24" fill="none" stroke="currentColor" strokeWidth="2.5"/>
            <path d="M32 20v16l8 8" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"/>
            <circle cx="48" cy="16" r="8" fill="none" stroke="currentColor" strokeWidth="2"/>
            <path d="M48 12v8M44 16h8" stroke="currentColor" strokeWidth="2"/>
          </svg>
        </div>
      );
    case "mobile":
      return (
        <div className={`${baseClasses} bg-lavender border border-purple/20`}>
          <svg width="64" height="64" viewBox="0 0 64 64" className="text-purple">
            <rect x="22" y="12" width="20" height="40" rx="4" fill="none" stroke="currentColor" strokeWidth="2.5"/>
            <circle cx="32" cy="18" r="2" fill="currentColor"/>
            <path d="M26 46h12" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
          </svg>
        </div>
      );
    case "chat":
      return (
        <div className={`${baseClasses} bg-gradient-primary`}>
          <svg width="64" height="64" viewBox="0 0 64 64" className="text-white">
            <path d="M16 20c0-2 2-4 4-4h24c2 0 4 2 4 4v16c0 2-2 4-4 4H24l-8 8v-8z" fill="none" stroke="currentColor" strokeWidth="2.5"/>
            <path d="M24 28h16M24 34h12" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
          </svg>
        </div>
      );
    default:
      return <div className={`${baseClasses} bg-lavender`}></div>;
  }
};

export const EnhancedFeaturesSection = () => {
  const backgrounds = ['bg-white', 'bg-[#F4F0FF]', 'bg-[#F8F8F8]'];
  
  return (
    <section id="features">
      {/* Section Header */}
      <div className="py-24 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl lg:text-5xl font-bold text-black mb-8">
            Features that{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              understand you
            </span>
          </h2>
          <p className="text-xl text-black/70 max-w-3xl mx-auto">
            DUBBY goes beyond word-for-word translation to capture meaning, context, and cultural nuance.
          </p>
        </div>
      </div>

      {/* Features List - Full-width rows with alternating backgrounds */}
      {features.map((feature, index) => (
        <div
          key={index}
          className={`py-24 ${backgrounds[index % backgrounds.length]} animate-fade-in`}
          style={{ animationDelay: `${index * 200}ms` }}
        >
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className={`flex flex-col ${
              index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'
            } items-center gap-16`}>
              {/* Visual */}
              <div className="w-full lg:w-1/2">
                <FeatureVisual type={feature.visual} />
              </div>

              {/* Content */}
              <div className="w-full lg:w-1/2 space-y-6">
                <h3 className="text-3xl lg:text-4xl font-bold text-black leading-tight">
                  {feature.title}
                </h3>
                <p className="text-lg text-navy/80 font-medium">
                  {feature.subtitle}
                </p>
                <p className="text-xl text-black/70 leading-relaxed">
                  {feature.description}
                </p>
              </div>
            </div>
          </div>
        </div>
      ))}
    </section>
  );
};