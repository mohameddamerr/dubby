import { Button } from "@/components/ui/button";

export const VisualStorySection = () => {
  const stories = [
    {
      title: "Mohamed in Paris",
      description: "Asks for directions → gets polite native response",
      original: "أين محطة المترو؟",
      translation: "Où est la station de métro, s'il vous plaît ?",
      context: "Polite & Respectful"
    },
    {
      title: "Tour Guide & Spanish Tourists",
      description: "Explaining local history seamlessly",
      original: "This cathedral was built in 1163...",
      translation: "Esta catedral fue construida en 1163...",
      context: "Informative & Engaging"
    },
    {
      title: "International Business Call",
      description: "Japanese and Brazilian speakers connecting",
      original: "このプロジェクトについて話し合いましょう",
      translation: "Vamos discutir este projeto",
      context: "Professional & Clear"
    },
    {
      title: "Couple Traveling Together",
      description: "Ordering dinner across languages",
      original: "What do you recommend for seafood?",
      translation: "Cosa ci consigli per il pesce?",
      context: "Casual & Friendly"
    }
  ];

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-20">
          <h2 className="text-4xl lg:text-6xl font-bold text-black mb-8">
            Real conversations.{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              Real connections.
            </span>
          </h2>
          <p className="text-xl text-black/70 max-w-2xl mx-auto">
            See how Dubby transforms everyday moments into meaningful connections across cultures.
          </p>
        </div>

        {/* Stories grid */}
        <div className="grid md:grid-cols-2 gap-8">
          {stories.map((story, index) => (
            <div 
              key={index}
              className="group bg-gradient-card rounded-3xl p-8 shadow-card hover:shadow-elegant transition-all duration-500 border border-purple/10"
            >
              {/* Story header */}
              <div className="mb-6">
                <h3 className="text-2xl font-bold text-black mb-2">{story.title}</h3>
                <p className="text-black/60">{story.description}</p>
              </div>

              {/* Conversation */}
              <div className="space-y-4">
                {/* Original */}
                <div className="bg-lavender rounded-2xl p-4">
                  <div className="text-sm font-medium text-purple mb-1">Original</div>
                  <div className="text-black font-medium">{story.original}</div>
                </div>

                {/* Arrow */}
                <div className="flex justify-center">
                  <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center">
                    <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                    </svg>
                  </div>
                </div>

                {/* Translation */}
                <div className="bg-white border border-purple/20 rounded-2xl p-4">
                  <div className="text-sm font-medium text-purple mb-1">Dubby Translation</div>
                  <div className="text-black font-medium mb-2">{story.translation}</div>
                  <div className="text-sm text-black/60">Tone: {story.context}</div>
                </div>
              </div>

              {/* Visual indicator */}
              <div className="mt-6 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-purple rounded-full animate-pulse"></div>
                  <span className="text-sm text-black/60">Live translation</span>
                </div>
                <div className="text-sm text-purple font-medium">
                  ~150ms response
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Call to action */}
        <div className="text-center mt-16">
          <div className="bg-lavender rounded-3xl p-8 max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-black mb-4">
              Your story starts here
            </h3>
            <p className="text-black/70 mb-6">
              Join thousands of travelers, creators, and global professionals breaking down language barriers.
            </p>
            <Button variant="premium" size="lg" className="px-8">
              Start Your Journey
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};