import { Button } from "@/components/ui/button";

export const AppIdentitySection = () => {
  return (
    <section className="py-24 bg-lavender/30">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-black mb-6">
            Your AI interpreter.{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              Always in your pocket.
            </span>
          </h2>
            <p className="text-xl text-black/70 max-w-2xl mx-auto">
              DUBBY is a mobile app designed for real conversations, real travel, and real human connections.
            </p>
        </div>

        {/* App mockup area */}
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Mobile App Showcase */}
          <div className="relative">
            <div className="bg-gradient-card rounded-[3rem] p-8 shadow-soft border border-purple/10">
              {/* Phone mockup */}
              <div className="bg-black rounded-[2.5rem] p-2 mx-auto w-80">
                <div className="bg-white rounded-[2rem] p-6 h-[700px] flex flex-col">
                  {/* Status bar */}
                  <div className="flex justify-between items-center mb-6 text-black text-sm">
                    <span>9:41</span>
                    <div className="flex space-x-1">
                      <div className="w-4 h-2 bg-black rounded-sm"></div>
                      <div className="w-4 h-2 bg-black rounded-sm"></div>
                      <div className="w-4 h-2 bg-black/30 rounded-sm"></div>
                    </div>
                  </div>
                  
                  {/* App interface */}
                  <div className="flex-1 flex flex-col">
                    <div className="text-center mb-6">
                      <h3 className="text-lg font-bold text-black mb-1">DUBBY</h3>
                      <p className="text-xs text-black/60">🇸🇦 Arabic → 🇫🇷 French</p>
                    </div>
                    
                    {/* Live translation display */}
                    <div className="bg-lavender rounded-2xl p-4 mb-4">
                      <div className="text-xs text-purple font-medium mb-1">Speaking Arabic</div>
                      <div className="text-sm font-medium text-black">أريد أن أطلب القهوة</div>
                      <div className="flex items-center mt-2">
                        <div className="w-2 h-2 bg-purple rounded-full animate-pulse mr-2"></div>
                        <span className="text-xs text-black/60">Listening...</span>
                      </div>
                    </div>
                    
                    {/* Translation output */}
                    <div className="bg-white border border-purple/20 rounded-2xl p-4 mb-6">
                      <div className="text-xs text-purple font-medium mb-1">French (Parisian)</div>
                      <div className="text-sm font-medium text-black">Je voudrais commander un café</div>
                      <div className="text-xs text-purple bg-purple/10 px-2 py-1 rounded-full inline-block mt-2">
                        Polite & Natural
                      </div>
                    </div>
                    
                    {/* Big translate button */}
                    <div className="flex-1 flex items-center justify-center">
                      <div className="w-24 h-24 bg-gradient-primary rounded-full flex items-center justify-center shadow-glow">
                        <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                        </svg>
                      </div>
                    </div>
                    
                    {/* Bottom actions */}
                    <div className="flex justify-center space-x-4">
                      <div className="bg-lavender rounded-full p-3">
                        <svg className="w-4 h-4 text-purple" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M6 12h.01M15 12a3 3 0 01-6 0" />
                        </svg>
                      </div>
                      <div className="bg-lavender rounded-full p-3">
                        <svg className="w-4 h-4 text-purple" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z" />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Floating features */}
            <div className="absolute -top-4 -right-4 bg-purple text-white px-4 py-2 rounded-full text-sm font-medium animate-float">
              iOS & Android
            </div>
            <div className="absolute -bottom-4 -left-4 bg-white border border-purple/20 text-black px-4 py-2 rounded-full text-sm font-medium shadow-soft animate-float delay-500">
              Real-time AI
            </div>
          </div>

          {/* Features list */}
          <div className="space-y-8">
            <div className="space-y-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-purple/10 rounded-2xl flex items-center justify-center">
                  <svg className="w-6 h-6 text-purple" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-semibold text-black text-lg">Works offline</h3>
                  <p className="text-black/60">Core features available without internet</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-purple/10 rounded-2xl flex items-center justify-center">
                  <svg className="w-6 h-6 text-purple" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-5 5h5m-5-5h-5v-5h5v5z" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-semibold text-black text-lg">Privacy first</h3>
                  <p className="text-black/60">Your conversations stay on your device</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-purple/10 rounded-2xl flex items-center justify-center">
                  <svg className="w-6 h-6 text-purple" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-semibold text-black text-lg">Lightning fast</h3>
                  <p className="text-black/60">Translations in under 200ms</p>
                </div>
              </div>
            </div>

            {/* Coming soon notice */}
            <div className="bg-lavender rounded-2xl p-6 border border-purple/20">
              <h4 className="font-bold text-black mb-2">Early Access</h4>
              <p className="text-black/70 mb-4">
                Be among the first to experience natural AI translation on mobile.
              </p>
              <Button variant="demo" className="w-full">
                Join Beta Waitlist
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};