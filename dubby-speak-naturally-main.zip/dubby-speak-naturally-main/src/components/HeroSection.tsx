import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

const demoData = [
  {
    input: { lang: "Arabic (Egypt)", text: "أنا جعان موت", flag: "🇪🇬" },
    output: { lang: "French (Slang)", text: "J'ai grave la dalle", tone: "Natural & Local", flag: "🇫🇷" }
  },
  {
    input: { lang: "Spanish (Mexico)", text: "¿Qué onda?", flag: "🇲🇽" },
    output: { lang: "English (Casual)", text: "What's up?", tone: "Casual & Cool", flag: "🇺🇸" }
  },
  {
    input: { lang: "English (US)", text: "Gotta bounce", flag: "🇺🇸" },
    output: { lang: "Japanese (Tokyo)", text: "もう行かなきゃ", tone: "Casual & Native", flag: "🇯🇵" }
  },
  {
    input: { lang: "Arabic (Levant)", text: "أنا طاير من الفرح", flag: "🇱🇧" },
    output: { lang: "Spanish (Slang)", text: "Estoy flipando", tone: "Excited & Local", flag: "🇪🇸" }
  }
];

export const HeroSection = () => {
  const [currentDemo, setCurrentDemo] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const [currentHeadline, setCurrentHeadline] = useState(0);
  
  const headlines = [
    "Speak like a local. Anywhere.",
    "Officially, you can now speak any language in the world fluently."
  ];

  useEffect(() => {
    const demoInterval = setInterval(() => {
      setIsAnimating(true);
      setTimeout(() => {
        setCurrentDemo((prev) => (prev + 1) % demoData.length);
        setIsAnimating(false);
      }, 300);
    }, 4000);

    const headlineInterval = setInterval(() => {
      setCurrentHeadline((prev) => (prev + 1) % headlines.length);
    }, 3000);

    return () => {
      clearInterval(demoInterval);
      clearInterval(headlineInterval);
    };
  }, []);

  const handleTryDemo = () => {
    // Check if user is in waitlist, for now redirect to waitlist
    window.location.href = '/waitlist';
  };

  const handleJoinWaitlist = () => {
    window.location.href = '/waitlist';
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center bg-white px-4 pt-20 overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-32 h-32 bg-lavender rounded-full blur-xl opacity-60 animate-float"></div>
        <div className="absolute bottom-32 right-10 w-24 h-24 bg-purple/20 rounded-full blur-xl opacity-80 animate-float delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full h-2 bg-gradient-flow opacity-10 animate-flow"></div>
      </div>
      
      {/* Main content */}
      <div className="max-w-6xl mx-auto relative z-10">
        {/* Logo */}
        <div className="flex justify-center mb-12 animate-fade-in">
          <div className="relative">
            <svg width="64" height="64" viewBox="0 0 64 64" className="text-black">
              <path 
                d="M16 24c0-4 3-8 8-8s8 4 8 8v16c0 4-3 8-8 8s-8-4-8-4v-16z" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="3" 
                strokeLinecap="round"
                className="animate-draw"
                style={{ strokeDasharray: 200, strokeDashoffset: 200 }}
              />
              <path 
                d="M40 32c2 0 4-2 6-2s4 2 6 2M40 40c3 0 6-2 9-2s6 2 9 2M40 24c2 0 4-2 6-2s4 2 6 2" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2.5" 
                strokeLinecap="round"
                className="animate-draw"
                style={{ strokeDasharray: 100, strokeDashoffset: 100, animationDelay: '0.5s' }}
              />
            </svg>
            <div className="absolute -bottom-3 left-1/2 transform -translate-x-1/2">
              <span className="text-2xl font-bold text-black tracking-wider">DUBBY</span>
            </div>
          </div>
        </div>

        {/* Main headline */}
        <div className="text-center mb-16">
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-black mb-6 leading-tight animate-slide-up min-h-[200px] flex items-center justify-center">
            <span className={`transition-all duration-500 ${currentHeadline === 0 ? 'opacity-100 transform-none' : 'opacity-0 transform translate-y-4'} ${currentHeadline === 0 ? 'block' : 'hidden'}`}>
              Speak like a local.{" "}
              <span className="bg-gradient-primary bg-clip-text text-transparent">
                Anywhere.
              </span>
            </span>
            <span className={`transition-all duration-500 ${currentHeadline === 1 ? 'opacity-100 transform-none' : 'opacity-0 transform translate-y-4'} ${currentHeadline === 1 ? 'block' : 'hidden'}`}>
              <span className="bg-gradient-primary bg-clip-text text-transparent">
                Officially, you can now speak any language in the world fluently.
              </span>
            </span>
          </h1>
          
          {/* Subtitle */}
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 mb-8 border border-lavender/50 shadow-soft max-w-4xl mx-auto">
            <p className="text-xl sm:text-2xl text-black/80 font-medium leading-relaxed">
              DUBBY translates your voice in real-time — understanding your meaning, dialect, and tone.
            </p>
          </div>
        </div>

        {/* iPhone 16 Pro Max Demo */}
        <div className="mb-16 animate-scale-in">
          <div className="max-w-md mx-auto">
            {/* iPhone 16 Pro Max mockup - accurate proportions */}
            <div className="relative bg-black rounded-[3.5rem] p-1 mx-auto w-80 shadow-2xl" style={{ aspectRatio: '9/19.5' }}>
              <div className="bg-white rounded-[3rem] h-full relative overflow-hidden">
                {/* Dynamic Island */}
                <div className="absolute top-2 left-1/2 transform -translate-x-1/2 w-32 h-8 bg-black rounded-full"></div>
                
                {/* App interface */}
                <div className="pt-16 pb-8 px-6 h-full flex flex-col">
                  {/* Status bar */}
                  <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center space-x-2">
                      <svg width="24" height="24" viewBox="0 0 24 24" className="text-black">
                        <path 
                          d="M6 9c0-1.5 1-3 3-3s3 1.5 3 3v6c0 1.5-1 3-3 3s-3-1.5-3-3v-6z" 
                          fill="none" 
                          stroke="currentColor" 
                          strokeWidth="2" 
                          strokeLinecap="round"
                        />
                        <path 
                          d="M15 12c0.5 0 1-0.5 1.5-0.5s1 0.5 1.5 0.5M15 15c0.75 0 1.5-0.5 2.25-0.5s1.5 0.5 2.25 0.5M15 9c0.5 0 1-0.5 1.5-0.5s1 0.5 1.5 0.5" 
                          fill="none" 
                          stroke="currentColor" 
                          strokeWidth="1.5" 
                          strokeLinecap="round"
                        />
                      </svg>
                      <span className="font-bold text-black text-sm">DUBBY</span>
                    </div>
                    <div className="text-xs text-black/60 bg-purple/10 px-2 py-1 rounded-full">Live Translation</div>
                  </div>

                  {/* Demo content */}
                  <div className={`flex-1 transition-all duration-300 ${isAnimating ? 'opacity-50 scale-95' : 'opacity-100 scale-100'}`}>
                    {/* Input */}
                    <div className="mb-6">
                      <div className="bg-lavender rounded-2xl p-4 mb-4">
                        <div className="flex items-center space-x-2 mb-2">
                          <span className="text-lg">{demoData[currentDemo].input.flag}</span>
                          <span className="text-xs font-medium text-purple">{demoData[currentDemo].input.lang}</span>
                        </div>
                        <div className="text-base font-medium text-black mb-2">
                          {demoData[currentDemo].input.text}
                        </div>
                        <div className="flex items-center text-xs text-black/60">
                          <div className="w-1.5 h-1.5 bg-purple rounded-full animate-pulse mr-2"></div>
                          Listening...
                        </div>
                      </div>
                    </div>

                    {/* Translation indicator */}
                    <div className="flex justify-center mb-6">
                      <div className="w-10 h-10 bg-gradient-primary rounded-full flex items-center justify-center shadow-glow animate-pulse">
                        <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                        </svg>
                      </div>
                    </div>

                    {/* Output */}
                    <div className="bg-white rounded-2xl p-4 border border-purple/20 shadow-soft">
                      <div className="flex items-center space-x-2 mb-2">
                        <span className="text-lg">{demoData[currentDemo].output.flag}</span>
                        <span className="text-xs font-medium text-purple">{demoData[currentDemo].output.lang}</span>
                      </div>
                      <div className="text-base font-medium text-black mb-2">
                        {demoData[currentDemo].output.text}
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-purple font-medium bg-purple/10 px-2 py-1 rounded-full">
                          {demoData[currentDemo].output.tone}
                        </span>
                        <button className="text-purple hover:text-purple/80 transition-colors">
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M6.343 6.343a9 9 0 000 12.728M4.929 4.929a11 11 0 000 14.142" />
                          </svg>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Demo indicators */}
                  <div className="flex justify-center space-x-2 mt-4">
                    {demoData.map((_, index) => (
                      <div
                        key={index}
                        className={`w-1.5 h-1.5 rounded-full transition-colors ${
                          index === currentDemo ? 'bg-purple' : 'bg-black/20'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* CTA buttons */}
        <div className="flex flex-col sm:flex-row gap-6 justify-center items-center animate-fade-in">
          <Button 
            variant="premium" 
            size="lg" 
            className="px-10 py-4 text-lg bg-gradient-primary hover:opacity-90"
            onClick={handleTryDemo}
          >
            Try Demo
          </Button>
          <Button 
            variant="premium-outline" 
            size="lg" 
            className="px-10 py-4 text-lg border-2 border-black hover:bg-black hover:text-white"
            onClick={handleJoinWaitlist}
          >
            Join Waitlist
          </Button>
        </div>

        {/* App badges placeholder */}
        <div className="mt-12 flex justify-center space-x-6 animate-fade-in">
          <div className="text-black/40 text-sm">
            Coming soon to iOS & Android
          </div>
        </div>
      </div>
    </section>
  );
};